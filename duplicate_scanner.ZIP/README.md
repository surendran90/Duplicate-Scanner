# 🔍 Duplicate Photo/Video & Folder Scanner

A Python 3 command-line tool for macOS that scans external HDDs (or any directory) to find duplicate folders and files (photos/videos), generates an interactive HTML report for review, and lets you delete duplicates only after your approval.

**No dependencies required** — runs on pure Python 3 (pre-installed on macOS).

---

## Table of Contents

1. [How It Works](#how-it-works)
2. [Quick Start](#quick-start)
3. [Command Reference](#command-reference)
4. [Workflow](#workflow)
5. [HTML Report Guide](#html-report-guide)
6. [Deletion Process](#deletion-process)
7. [Supported File Types](#supported-file-types)
8. [Performance Notes](#performance-notes)
9. [Safety & Precautions](#safety--precautions)
10. [Troubleshooting](#troubleshooting)
11. [Examples](#examples)

---

## How It Works

The scanner runs in two phases:

### Phase 1 — Duplicate Folder Detection

Finds entire folder copies, even if the folder was renamed. This lets you delete one folder instead of hundreds of individual files.

- Computes a "content signature" for each folder using relative file paths + file sizes
- Verifies matches with full SHA-256 hash of every file in the folder
- Groups are sorted by wasted space (largest first)

### Phase 2 — Duplicate File Detection

Uses a fast 3-stage pipeline to avoid hashing every file:

```
Stage 1: Group by file size
         (duplicates must be the same size — instant filter)
              ↓
Stage 2: Partial hash (first 64KB only)
         (eliminates most false positives cheaply)
              ↓
Stage 3: Full SHA-256 hash
         (confirms true duplicates with certainty)
```

This means for a 400GB drive, only a small fraction of files actually get fully hashed.

---

## Quick Start

```bash
# 1. Plug in your external HDD

# 2. Find your HDD's mount path
ls /Volumes/

# 3. Run the scanner
python3 duplicate_scanner.py /Volumes/YourHDDName

# 4. Report opens automatically in your browser
#    Review → Select duplicates → Generate delete script → Run it
```

---

## Command Reference

```
python3 duplicate_scanner.py <path> [options]
```

### Required Argument

| Argument | Description |
|----------|-------------|
| `path` | Root directory to scan (e.g., `/Volumes/MyHDD`, `~/Pictures`) |

### Options

| Flag | Description | Default |
|------|-------------|---------|
| `--output`, `-o` | Output report file path | `~/Desktop/duplicate_report.html` |
| `--min-size` | Minimum file size in bytes to consider | `1024` (1 KB) |
| `--all-files` | Scan ALL file types, not just photos/videos | Off |
| `--report-only` | Generate report only, no interactive prompts | Off |
| `--skip-folders` | Skip duplicate folder detection (faster scan) | Off |
| `--skip-files` | Skip duplicate file detection | Off |

---

## Workflow

```
┌──────────────────────────┐
│  1. Run the scanner      │
│     python3 ...          │
└──────────┬───────────────┘
           ↓
┌──────────────────────────┐
│  2. Scan completes       │
│     Report opens in      │
│     your browser         │
└──────────┬───────────────┘
           ↓
┌──────────────────────────┐
│  3. Review the report    │
│     - Duplicate folders  │
│     - Duplicate files    │
│     - Check what to      │
│       delete             │
└──────────┬───────────────┘
           ↓
┌──────────────────────────┐
│  4. Generate delete      │
│     script (.sh file)    │
│     OR export .txt list  │
└──────────┬───────────────┘
           ↓
┌──────────────────────────┐
│  5. Review the script    │
│     Open it in a text    │
│     editor first!        │
└──────────┬───────────────┘
           ↓
┌──────────────────────────┐
│  6. Run the script       │
│     chmod +x delete_...  │
│     ./delete_duplicates  │
└──────────────────────────┘
```

---

## HTML Report Guide

The report opens in your default browser and includes:

### Stats Dashboard
- Number of duplicate folder groups
- Number of duplicate file groups
- Wasted space by folders and files
- Total reclaimable space

### Duplicate Folders Section
- Each group shows all copies of a folder
- First copy is marked with a green bar (auto-keep)
- Shows file count and folder size for each copy

### Duplicate Files Section
- Each group shows all copies of a file
- Shows file extension, size, and last modified date
- Sorted by wasted space (largest waste first)

### Interactive Controls
- **Auto-select duplicates (keep first)** — Checks all copies except the first in every group
- **Clear all** — Unchecks everything
- **Collapse/Expand** — Toggle individual groups
- **Bottom bar** — Shows selected count and space to free
- **Export deletion list** — Downloads a `.txt` file of selected paths
- **Generate delete script** — Downloads a `.sh` bash script

---

## Deletion Process

**Nothing is ever deleted automatically.** The process is:

1. You select items in the HTML report using checkboxes
2. Click "Generate delete script" — downloads `delete_duplicates.sh`
3. Open the `.sh` file in a text editor and review it
4. Run it in Terminal:

```bash
chmod +x delete_duplicates.sh
./delete_duplicates.sh
```

If you prefer a text list for manual deletion:
- Click "Export deletion list" to get a `.txt` file with all selected paths

---

## Supported File Types

By default, only media files are scanned:

### Images
`.jpg` `.jpeg` `.png` `.gif` `.bmp` `.tiff` `.tif` `.heic` `.heif` `.webp` `.raw` `.cr2` `.nef` `.arw` `.dng` `.svg` `.ico` `.psd`

### Videos
`.mp4` `.mov` `.avi` `.mkv` `.wmv` `.flv` `.m4v` `.mpg` `.mpeg` `.3gp` `.webm` `.ts` `.mts` `.m2ts` `.vob` `.divx`

To scan **all** file types, use the `--all-files` flag.

---

## Performance Notes

| Drive Size | Estimated Time | Notes |
|------------|---------------|-------|
| 50 GB | 5–10 min | Quick scan |
| 200 GB | 15–30 min | Moderate |
| 400 GB | 30–60 min | Depends on number of duplicates |
| 1 TB+ | 1–2 hours | Consider using `--skip-folders` |

### Tips for faster scans:
- Use `--skip-folders` if you only care about file duplicates
- Use `--min-size 1048576` to skip files under 1 MB
- USB 3.0+ ports will be significantly faster than USB 2.0
- Avoid running other disk-heavy tasks during the scan

---

## Safety & Precautions

- ✅ **Read-only scan** — The script never modifies or deletes anything during scanning
- ✅ **Manual approval** — Deletion only happens via a separate script you review first
- ✅ **Keep-first logic** — The first copy in each group is marked "keep" by default
- ✅ **No dependencies** — Pure Python 3, nothing to install

### Recommended precautions:
- 🔸 **Back up critical data** before running any delete script
- 🔸 **Review the `.sh` script** in a text editor before executing
- 🔸 **Start with `--report-only`** on your first run to just see results
- 🔸 **Test on a small folder first** before scanning the whole drive

---

## Troubleshooting

### "Permission denied" errors
```bash
# Run with elevated permissions if needed
sudo python3 duplicate_scanner.py /Volumes/MyHDD
```

### HDD not showing up
```bash
# List mounted volumes
ls /Volumes/

# If not listed, check Disk Utility or re-mount
diskutil list
```

### Scan is too slow
```bash
# Skip folder detection + ignore small files
python3 duplicate_scanner.py /Volumes/MyHDD --skip-folders --min-size 1048576
```

### Report doesn't open in browser
```bash
# Open manually
open ~/Desktop/duplicate_report.html
```

### "python3 not found"
```bash
# Check if Python is installed
which python3

# If not, install via Homebrew
brew install python3
```

---

## Examples

```bash
# Basic scan of external HDD (photos/videos only)
python3 duplicate_scanner.py /Volumes/MyHDD

# Scan everything, not just media files
python3 duplicate_scanner.py /Volumes/MyHDD --all-files

# Skip small files (under 1MB) for faster results
python3 duplicate_scanner.py /Volumes/MyHDD --min-size 1048576

# Only find duplicate files, skip folder comparison
python3 duplicate_scanner.py /Volumes/MyHDD --skip-folders

# Only find duplicate folders
python3 duplicate_scanner.py /Volumes/MyHDD --skip-files

# Save report to a custom location
python3 duplicate_scanner.py /Volumes/MyHDD -o ~/Documents/hdd_dupes.html

# Scan local Pictures folder
python3 duplicate_scanner.py ~/Pictures

# Just generate report, no prompts
python3 duplicate_scanner.py /Volumes/MyHDD --report-only
```

---

*Generated with Claude — April 2026*
